# Cucumber, Java, jUnit + Maven Snippets

A short demonstration how to set-up cucumber in a mavenized Java environment.

Please feel free to have a look at [my blog] for the full tutorial.

----

**2014 Micha Kops / hasCode.com**

   [my blog]:http://www.hascode.com/
